name = "PySimpleGUI"
from .PySimpleGUI import *
from .PySimpleGUI import __version__
